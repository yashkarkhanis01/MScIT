import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
data = pd.read_csv('Mall_Customers.csv', header=None, names=['x', 'y'])
data['x'] = pd.to_numeric(data['x'], errors='coerce')
data['y'] = pd.to_numeric(data['y'], errors='coerce')
sns.jointplot(data=data, x='x', y='y', kind='kde')
plt.show()
