def drug_user(
        prob_th=0.80,
        sensitivity=0.09,
        specificity=0.89,
        prevelance=0.69,
        verbose=True):


    p_user = prevelance
    p_non_user = 1-prevelance
    p_pops_user = sensitivity
    p_neg_user = specificity
    p_pops_non_user = 1-specificity

    num = p_pops_user*p_user
    den = p_pops_user*p_user+p_pops_non_user*p_non_user
    prob = num/den

    if verbose:
        if prob > prob_th:
            print("The test-taker could be an user")
        else:
            print("The test-taker may not be an user")

    return prob

print("Yash Karkhanis")
p=drug_user(prob_th=0.5, sensitivity=0.9, specificity=0.5, prevelance=0.005)
print("Probablity of the test-taker being a drug user is:", round(p,3))