import aiml
kernel = aiml.Kernel()
kernel.learn("std-startup.xml")
kernel.learn("basic_chat.aiml") 
while True:
    input_text = input(">Human: ")
    response = kernel.respond(input_text)
    print(">Bot: " + response)